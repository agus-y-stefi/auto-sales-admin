#!/bin/bash
set -e

echo "Esperando que Python termine la migración inicial..."
while [ ! -f /shared/ready.flag ]; do
  sleep 2
done

export PGPASSWORD=postgres

PG_HOST="host.docker.internal"
CENTRAL_PORT=5438
CUSTOMERS_PORT=5439
ORDERS_PORT=5440
PRODUCTS_PORT=5441
USER="postgres"
CENTRAL_DB="classicmodels_pg"
CUSTOMERS_DB="ms-customers-db"
ORDERS_DB="ms-orders-db"
PRODUCTS_DB="ms-products-db"

echo "Esperando base central..."
until pg_isready -h $PG_HOST -p $CENTRAL_PORT -U $USER; do
  echo "Esperando $CENTRAL_DB..."
  sleep 2
done

echo "Esperando bases microservicios..."
until pg_isready -h $PG_HOST -p $CUSTOMERS_PORT -U $USER; do
  echo "Esperando $CUSTOMERS_DB..."
  sleep 2
done

until pg_isready -h $PG_HOST -p $ORDERS_PORT -U $USER; do
  echo "Esperando $ORDERS_DB..."
  sleep 2
done

until pg_isready -h $PG_HOST -p $PRODUCTS_PORT -U $USER; do
  echo "Esperando $PRODUCTS_DB..."
  sleep 2
done

# Exportar customers
echo "Dump completo customers..."
pg_dump -h $PG_HOST -p $CENTRAL_PORT -U $USER -d $CENTRAL_DB \
  -n classicmodels \
  -t classicmodels.customers -t classicmodels.offices -t classicmodels.employees \
  --column-inserts --clean > /tmp/customers_full.sql

# Reemplazar esquema classicmodels por public para importar en destino
sed -i 's/classicmodels\./public./g' /tmp/customers_full.sql

echo "Importando a ms-customers-db..."
psql -h $PG_HOST -p $CUSTOMERS_PORT -U $USER -d $CUSTOMERS_DB < /tmp/customers_full.sql

# Exportar orders
echo "Dump completo orders..."
pg_dump -h $PG_HOST -p $CENTRAL_PORT -U $USER -d $CENTRAL_DB \
  -n classicmodels \
  -t classicmodels.
